# Holidays Lambda API
====

Holidays API returns a list of classified Holidays in India. This is a Playground to dabble with AWS Lambda and API Gateway.

## Installation

    npm install

## Deploy Function to Lambda

Configure AWS CLI and then run the following command:

	npm run-script deploy

## Test

	npm test

## API

I've currently configured API Gateway on AWS Console.

